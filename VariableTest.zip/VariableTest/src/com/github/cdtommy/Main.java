package com.github.cdtommy;

public class Main {

    public static void main(String[] args) {
	var myInteger = 34;
	var myDouble = 95.5;
    var myBoolean = true;
    var myChar = "A";
    var myString = "Hello";
    System.out.println("myInteger " +myInteger);
    System.out.println("myDouble " +myDouble);
    System.out.println("myBoolean " +myBoolean);
    System.out.println("myChar " +myChar);
    System.out.println("myString " +myString);
    }
}
