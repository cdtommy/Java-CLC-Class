/* This software is licensed under the GNU General Public License version 3.0
    To learn more about this license and what you can do with this software go here
 */

package com.github.cdtommy;
import java.lang.System;
import java.util.Calendar;
import java.util.Date;

public class ShowTime {
    public static void main(String[] args) {
        var today = (Calendar.getInstance().getTime());
        String text = ("Hello \nToday's date is\n" + today);
        int i;
        for(i = 0; i < text.length(); i++){
            System.out.printf("%c", text.charAt(i));
            try{
                Thread.sleep(250);
            }catch(InterruptedException ex){
                Thread.currentThread().interrupt();
            }

    }
    }
}
