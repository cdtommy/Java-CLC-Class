package com.github.cdtommy;

public class Main {

    public static void main(String[] args) {

        printCheckerboard();
    }

    static void printCheckerboard() {
        String a;
        int r = 5;
        int c = 3;
        for (int i = 0; i <= r; i++) {
            if (i % 2 == 0){
                a = "#  ";
            } else {
                a = " ";
            }
            for (int j = 0; j <= c; j++) {
                System.out.print(a);
            }
            System.out.print("\n");
        }
    }
}




